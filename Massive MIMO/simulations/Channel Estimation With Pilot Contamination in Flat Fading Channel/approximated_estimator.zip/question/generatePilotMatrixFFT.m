function [S] = generatePilotMatrixFFT(K)

S = fft(eye(K));

